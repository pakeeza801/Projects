import Home from './src/Home';
import SplashScreen from './src/SplashScreen';
import Navigator from './src/AppNavigator';
export default function App() {
  return (
    <Navigator />
  );
}

