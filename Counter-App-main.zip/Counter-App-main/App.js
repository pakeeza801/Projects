import React from 'react';
import Counter from './Counter_App/Counter';
export default function App() {
  return (
    <Counter />
  );
}

