export const AddTask = "addTask";
export const ChangeCompleteStatus = "changeCompleteStatus";
export const UpdateTask = "updateTask"
export const DeleteTask = "deleteTask"