export const SET_CATEGORY_OF_ITEMS = "set-category-of-items";
export const SEARCHED_DATA = "search-data";
export const SET_CART = "set-cart"
export const REMOVE_ITEM = "remove-item";